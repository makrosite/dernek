<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DuyuruSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
    \DB::table('duyurus')->insert([
        [
            'baslik' => 'Yeni Web Sitemiz Yayında!',
            'metin' => 'Kurumsal web sitemiz modern arayüzüyle yayına alınmıştır.',
            'resim' =>'ornek.jpg',
            'created_at' => now(),
            'updated_at' => now(),
        ]


    ]);
    }
}
